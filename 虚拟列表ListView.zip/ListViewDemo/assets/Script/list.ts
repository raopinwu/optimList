
import { _decorator, Component, Node, Label } from 'cc';
import SuperListView from './list/SuperListView';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = List
 * DateTime = Tue Jan 25 2022 13:22:43 GMT+0800 (中国标准时间)
 * Author = tombs_tang
 * FileBasename = list.ts
 * FileBasenameNoExtension = list
 * URL = db://assets/Script/list.ts
 * ManualUrl = https://docs.cocos.com/creator/3.3/manual/zh/
 *
 */

@ccclass('List')
export class List extends Component {
    // [1]
    // dummy = '';

    // [2]
    // @property
    // serializableDummy = 0;


    @property(SuperListView)
    list1: SuperListView = null;

    @property(SuperListView)
    list2: SuperListView = null;

    start() {
        // [3]

        this.listView1();
        this.listView2();
    }

    private listView1() {
        this.list1.getProvide = this.getProvide;
        let list = [];
        for (let index = 0; index < 5; index++) {
            list.push(index)
        }
        this.list1.dataArr = list
    }

    /** 设置元素资源 */
    public getProvide(index) {
        if (index % 4 == 0) {
            return 1;
        } if (index % 4 == 1) {
            return 2
        } if (index % 4 == 2) {
            return 3
        } else {
            return 0
        }

        // return Math.floor(Math.random() * 4);
    }

    onItemRender(item: Node, idx: number, data: any) {
        if (idx == 3) {
            item.getChildByName("Label").getComponent(Label).string = data + "";
        } if (idx == 1) {
            item.getChildByName("Label").getComponent(Label).string = data + "";
        } else {
            item.getChildByName("Label").getComponent(Label).string = data + "";
        }
    }


    private listView2() {
        this.list2.getProvide = this.getProvide2;
        let list = [];
        for (let index = 0; index < 5; index++) {
            list.push(index)
        }
        this.list2.dataArr = list
    }

    /** 设置元素资源 */
    public getProvide2(index) {
        return 2
        // return Math.floor(Math.random() * 4);
    }

    onItemRender2(item: Node, idx: number, data: any) {
        if (idx == 3) {
            item.getChildByName("Label").getComponent(Label).string = data + "";
        } if (idx == 1) {
            item.getChildByName("Label").getComponent(Label).string = data + "";
        } else {
            item.getChildByName("Label").getComponent(Label).string = data + "";
        }
    }


    onInsert() {
        this.list1.insert(["插入"], 0);
        this.list2.insert(["插入"], Math.max(this.list2.itemCount - 2, 0));
    }

    onDelete() {
        this.list1.delete(this.list1.itemCount - 1);
        this.list2.delete(0);
    }

    oScollTo() {
        this.list1.scollTo(5);
        this.list2.scollTo(0);
        // this.list2.getScoll().scrollToPercentVertical(0, 0.1, true)
    }


    // update (deltaTime: number) {
    //     // [4]
    // }
}

/**
 * [1] Class member could be defined like this.
 * [2] Use `property` decorator if your want the member to be serializable.
 * [3] Your initialization goes here.
 * [4] Your update function goes here.
 *
 * Learn more about scripting: https://docs.cocos.com/creator/3.3/manual/zh/scripting/
 * Learn more about CCClass: https://docs.cocos.com/creator/3.3/manual/zh/scripting/ccclass.html
 * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.3/manual/zh/scripting/life-cycle-callbacks.html
 */
