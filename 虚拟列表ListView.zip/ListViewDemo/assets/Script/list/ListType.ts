import { Enum, _decorator } from "cc";

const { ccclass} = _decorator;

/**
 * 列表顺序
 */
export enum ListOderType {
    Normal ,
    Reverse  // 倒叙
}
Enum(ListOderType);