/*
 * @Author: f.zohar 
 * @Date: 2021-05-11 11:53:08 
 * @Last Modified by: f.zohar
 * @Last Modified time: 2021-05-24 15:28:53
 * listview
 * 实现功能：
 * 1. 动态列表 智能排序
 * 2. 分帧加载
 * 3. 优化渲染
 * 4. 可反转（倒序列表 还有点问题在修复）
 * 5. 下拉刷新加载 TODO
 */

import { Component, Prefab, ScrollView, _decorator, Node, v2, Vec2, CCInteger, NodePool, instantiate, log, EventHandler, UITransform, size, Size, tween, Vec3, Tween, Rect, rect, ToggleContainer, Toggle } from "cc";
import { ListOderType } from "./ListType";
const { ccclass, property, disallowMultiple, requireComponent, executionOrder, menu } = _decorator;

@ccclass
@disallowMultiple()
@requireComponent(ScrollView)
// @menu("List/SuperListView")
//脚本生命周期回调的执行优先级。小于 0 的脚本将优先执行，大于 0 的脚本将最后执行。该优先级只对 onLoad, onEnable, start, update 和 lateUpdate 有效，对 onDisable 和 onDestroy 无效。
@executionOrder(-5000)
export default class SuperListView extends Component {
    /** item预制 */
    @property([Prefab])
    itemPrefabs: Prefab[] = [];
    /** 四周距离*/
    @property({ group: { name: 'margin' } })
    private readonly vertical: Vec2 = v2(0, 0);
    @property({ group: { name: 'margin' } })
    private readonly horizontal: Vec2 = v2(0, 0);
    /** 间隔 */
    @property({ group: { name: 'margin' } })
    private readonly spacing: Vec2 = v2(0, 0);
    /** 网格 */
    @property(CCInteger)
    private grid: number = 1;
    /** 反转列表 */
    @property({ type: ListOderType, tooltip: "反转列表" })
    private oderType: ListOderType = ListOderType.Normal;
    /**  循环 */
    @property({ tooltip: "是否循环列表" })
    private isLoop: boolean = false;
    /**
     * 列表刷新回调事件
     * onItemRender(item: Node, idx: number, data: any)
     */
    @property({ type: EventHandler, tooltip: "列表刷新回调事件" })
    public onListRender: EventHandler = null;

    // /**
    //  * Item点选中回调事件
    //  * onItemRender(item: Node, idx: number, data: any)
    //  */
    // @property({ type: EventHandler, tooltip: "选中/取消选中 Item回调(依赖ListToggleGroup)" })
    // public onSelectItem: EventHandler = null;

    /**
     * Item点击回调事件
     * onItemRender(item: Node, idx: number, data: any)
     */
    @property({ type: EventHandler, tooltip: "点击 Item回调(依赖ListToggleGroup)" })
    public onClickItem: EventHandler = null;

    //列表数据
    private _dataArr: Array<any> = [];
    private itemArray: Array<Node> = [];
    private itemProvides: Array<string> = [];
    // private _itemPool: NodePool = new NodePool();

    // 开启 区域外不显示减少draw call
    private isVirtual = true;
    //每帧处理item数量(保证流畅性)
    private renderNum: number = 1;
    // 滑动中
    private isScrollIng: boolean = false;

    // LIFE-CYCLE CALLBACKS:

    start() {
        // this.init();
    }

    public onLoad() {
        this.init();
    }

    // 初始
    private init() {
        // content
        this.initContent();
    }

    private initContent() {
        this.setContentSize(this.getZeroContentSize());

        let content = this.getScoll().content;
        // 锚点 坐标
        if (this.grid > 1) {
            if (this.oderType == ListOderType.Normal) {
                content.getComponent(UITransform).anchorX = 0;
                content.getComponent(UITransform).anchorY = 1;
                content.setPosition(-this.viewSize.width * 0.5, this.viewSize.height * 0.5, 0);
            } else {
                content.getComponent(UITransform).anchorX = 1;
                content.getComponent(UITransform).anchorY = 0;
                content.setPosition(this.viewSize.width * 0.5, this.viewSize.height * 0.5, 0);
            }
        } else {
            if (this.getScoll().horizontal) {
                content.getComponent(UITransform).anchorX = this.oderType == ListOderType.Normal ? 0 : 1;
                content.getComponent(UITransform).anchorY = 0.5;
                content.setPosition(this.viewSize.width * (content.getComponent(UITransform).anchorX - 0.5), 0, 0);
            } else {
                content.getComponent(UITransform).anchorX = 0.5;
                content.getComponent(UITransform).anchorY = this.oderType == ListOderType.Normal ? 1 : 0;
                content.setPosition(0, this.viewSize.height * (content.getComponent(UITransform).anchorY - 0.5), 0);
            }
        }
    }

    onEnable() {
        this._registerEvent();
    }
    onDisable() {
        // if (!CC_EDITOR) 
        this._unregisterEvent();
    }

    onDestroy() {
        // 清理释放
        this.clear();
        // this._itemPool.clear();
    }

    //注册事件
    _registerEvent() {
        // this.node.on(Node.EventType.TOUCH_START, this._onTouchStart, this, true);
        // // 当用户松手的时候会发出一个事件
        // this.node.on("touch-up", this._onTouchUp, this, true);

        // if (this.getScoll().horizontal) {
        //     this.node.on("scroll-to-left", this._onScrollToTLeft, this, true);
        //     this.node.on("scroll-to-right", this._onScrollToRight, this, true);
        //     // 滚动视图滚动到顶部边界并且开始回弹时发出的事件
        //     this.node.on("bounce-left", this._onBounceLeft, this, true);
        //     this.node.on("bounce-right", this._onBounceRight, this, true);
        // } else {
        //     this.node.on("scroll-to-top", this._onScrollToTop, this, true);
        //     this.node.on("scroll-to-bottom", this._onScrollToBottom, this, true);
        //     // 滚动视图滚动到顶部边界并且开始回弹时发出的事件
        //     this.node.on("bounce-top", this._onBounceTop, this, true);
        //     this.node.on("bounce-bottom", this._onBounceBottom, this, true);
        // }
        this.node.on("scroll-began", this._onScrollBegin, this, true);
        this.node.on("scrolling", this._onScrollIng, this, true);
        this.node.on("scroll-ended", this._onScrollEnded, this, true);

    }
    //卸载事件
    _unregisterEvent() {
        // this.node.off(Node.EventType.TOUCH_START, this._onTouchStart, this, true);
        // 当用户松手的时候会发出一个事件
        // this.node.off("touch-up", this._onTouchUp, this, true);

        // if (this.getScoll().horizontal) {
        //     this.node.off("scroll-to-left", this._onScrollToTLeft, this, true);
        //     this.node.off("scroll-to-right", this._onScrollToRight, this, true);
        //     // 滚动视图滚动到顶部边界并且开始回弹时发出的事件
        //     this.node.off("bounce-left", this._onBounceLeft, this, true);
        //     this.node.off("bounce-right", this._onBounceRight, this, true);
        // } else {
        //     this.node.off("scroll-to-top", this._onScrollToTop, this, true);
        //     this.node.off("scroll-to-bottom", this._onScrollToBottom, this, true);
        //     // 滚动视图滚动到顶部边界并且开始回弹时发出的事件
        //     this.node.off("bounce-top", this._onBounceTop, this, true);
        //     this.node.off("bounce-bottom", this._onBounceBottom, this, true);
        // }
        this.node.off("scroll-began", this._onScrollBegin, this, true);
        this.node.off("scrolling", this._onScrollIng, this, true);
        this.node.off("scroll-ended", this._onScrollEnded, this, true);
    }

    // 触摸时
    private _onTouchStart(ev, captureListeners) {
        // if (this.getScoll()['_hasNestedViewGroup'](ev, captureListeners))
        //     return;
    }
    // 当用户松手的时候会发出一个事件
    private _onTouchUp() {
        // log("_onTouchUp:");
    }
    // 滚动事件
    private _onScrollBegin(scroll: ScrollView) {
        // log("_onScrollBegin:");
    }
    private _onScrollIng(scroll: ScrollView) {
        // log("_onScrollIng:");
        this.isScrollIng = true;
    }
    private _onScrollEnded(scroll: ScrollView) {
        // log("_onScrollEnded:");
        let scrollOffset = this.getScoll().getScrollOffset();
        log("_onScrollEnded:", scrollOffset.toString());
        this.isScrollIng = false;
    }
    private _onScrollToTLeft(scroll: ScrollView) {
        log("_onScrollToTLeft:");
    }
    private _onScrollToRight(scroll: ScrollView) {
        log("_onScrollToRight:");
    }
    private _onScrollToTop(scroll: ScrollView) {
        log("_onScrollToTop:");
    }
    private _onScrollToBottom(scroll: ScrollView) {
        log("_onScrollToBottom:");
    }
    // 滚动视图滚动到顶部边界并且开始回弹时发出的事件
    private _onBounceLeft(scroll: ScrollView) {
        log("_onBounceLeft:");
    }
    private _onBounceRight(scroll: ScrollView) {
        log("_onBounceRight:");
    }
    private _onBounceTop(scroll: ScrollView) {
        let scrollOffset = this.getScoll().getScrollOffset();
        log("_onBounceTop:", scrollOffset.toString());
        if (scrollOffset.y > 50) {
            // 下拉刷新
        }
    }
    private _onBounceBottom(scroll: ScrollView) {
        log("_onBounceBottom:");
    }

    // ScrollView
    public getScoll(): ScrollView {
        return this.getComponent(ScrollView);
    }

    // 设置每次渲染个数
    public setRenderNum(num: number) {
        this.renderNum = num;
    }

    /** 设置元素资源 */
    public getProvide(index): number {
        return 0;
    }

    public get dataArr(): any {
        return this._dataArr;
    }
    // 设置数据源
    public set dataArr(arr: any) {
        if (arr.length <= 0) {
            return;
        }
        this.clear();
        this._dataArr = arr.slice();
        let range = [0, this._dataArr.length];
        this.notifyUpdate();
    }

    /**
     * 数据个数
     */
    public get itemCount() {
        return this._dataArr.length;
    }

    /**
     * 插入
     * @param itemArr  插入的数据
     * @param index 插入位置
     */
    public insert(itemArr: Array<any>, index: number) {
        if (index > this._dataArr.length || index < 0) {
            return;
        }
        let oldPercent = this.getScoll().getScrollOffset();
        this._dataArr.splice(index, 0, ...itemArr);
        let range = [index, this._dataArr.length];
        this.notifyUpdate();
        // this.scheduleOnce(() => {
        //     this.updateOpacity();
        // }, 0.05)
        this.scollTo(index);
    }

    /**
     * 删除
     * @param index 删除位置
     */
    public delete(index: number) {
        if (index >= this._dataArr.length || index < 0) {
            return;
        }
        let oldPercent = this.getScoll().getScrollOffset();
        this._dataArr.splice(index, 1);
        this.clearItem(index);
        let range = [index, this._dataArr.length];

        this.notifyUpdate();
        this.scheduleOnce(() => {
            this.updateOpacity();
        }, 0.05)
    }

    /**
     * 更改
     * @param item 
     * @param index 位置
     */
    public change(item: any, index: number) {
        if (index >= this._dataArr.length || index < 0) {
            return;
        }
        this._dataArr[index] = item;
        let range = [index, 1];
        this.notifyUpdate();
    }


    protected lateUpdate() {
        // if (this.isScrollIng) {
        this.updateOpacity();
        // }
    }

    // 刷新一次数据
    public notifyUpdate() {
        if (this.grid > 1) {
            if (this.getScoll().horizontal && !this.getScoll().vertical) {
                this.grid = Math.floor(this.itemCount / this.grid) + 1
            }
            this.notifyUpdateGrid();
        } else {
            this._notifyUpdate();
        }
        // this.updateOpacity();
    }

    private getItem(index: number) {
        let needNewItem: boolean = true;
        let provideIdx = this.getProvide(index);

        if (this.itemArray[index] && this.itemArray[index]["provideIdx"] == provideIdx) {
            needNewItem = false;
        }
        if (needNewItem) {
            let node = instantiate(this.itemPrefabs[this.getProvide(index)]);
            // 设置预制体的标记
            node["provideIdx"] = provideIdx;
            this.itemArray[index] = node;
            // Toggle
            this.checkToggle(node, index);
        }
        return this.itemArray[index];
    }

    private addItem(item: Node) {
        if (!item.parent) {
            this.getScoll().content.addChild(item);
        }
        // item.active = true;
    }

    private renderItem(index: number) {
        // if(!this.itemArray[index].active){
        //     return
        // }
        this.onListRender.customEventData = this._dataArr[index];
        EventHandler.emitEvents([this.onListRender], this.itemArray[index], index);
    }

    /**起始元素的坐标 */
    private getZeroPostion(): Vec2 {
        let pos = new Vec2(0, 0);
        if (this.getScoll().horizontal || this.grid > 1) {
            if (this.oderType == ListOderType.Normal) {
                pos.x = this.horizontal.x;
            } else {
                pos.x = -this.horizontal.x;
            }
        }
        if (this.getScoll().vertical || this.grid > 1) {
            if (this.oderType == ListOderType.Normal) {
                pos.y = -this.vertical.y;
            } else {
                pos.y = this.vertical.y;
            }
        }
        return pos;
    }

    /** 单行、单列 */
    private _notifyUpdate() {
        let index = 0
        let contentW = this.getZeroContentSize().width;
        let contentH = this.getZeroContentSize().height;
        while (index < this.itemCount) {
            let item = this.getItem(index);
            this.addItem(item);
            // 计算位置区域
            let w = item.getComponent(UITransform).width;
            let h = item.getComponent(UITransform).height;
            // 设置ContentSize
            contentW = contentW + w + (index == 0 ? 0 : this.spacing.x);
            contentH = contentH + h + (index == 0 ? 0 : this.spacing.y);
            index++;
        }
        this.setContentSize(size(contentW, contentH));
        this.cumulativePosition();
    }

    /** 计算位置 */
    private cumulativePosition() {
        let startPos = this.getZeroPostion();
        let prew = 0;
        let preh = 0;

        let index = 0
        while (index < this.itemCount) {
            let item = this.getItem(index);
            // 计算位置区域
            let w = item.getComponent(UITransform).width;
            let h = item.getComponent(UITransform).height;
            if (this.getScoll().horizontal) {
                if (this.oderType == ListOderType.Normal) {
                    startPos.x = startPos.x + w / 2 + prew / 2 + (index == 0 ? 0 : this.spacing.x);
                } else {
                    startPos.x = startPos.x - w / 2 - prew / 2 - (index == 0 ? 0 : this.spacing.x);
                }
            }
            if (this.getScoll().vertical) {
                if (this.oderType == ListOderType.Normal) {
                    startPos.y = startPos.y - h / 2 - preh / 2 - (index == 0 ? 0 : this.spacing.y);
                } else {
                    startPos.y = startPos.y + h / 2 + preh / 2 + (index == 0 ? 0 : this.spacing.y);
                }
            }
            prew = w;
            preh = h;

            // 位置还没设置 先检测是否可见
            item.active = this.checkCollision2(item, startPos.x, startPos.y, w, h) ? true : false;
            // 增加动画效果
            Tween.stopAllByTarget(item);
            tween(item).to(0.02, { position: new Vec3(startPos.x, startPos.y, 0) }).start();
            // 
            this.renderItem(index);
            index++;
        }
    }

    // 网格排列
    private notifyUpdateGrid() {
        let col = this.grid;
        let row = Math.floor(this.itemCount / this.grid) + 1;
        if (this.itemCount % this.grid == 0) {
            row = Math.floor(this.itemCount / this.grid)
        }
        let contentW = this.getZeroContentSize().width;
        let contentH = this.getZeroContentSize().height;
        let index = 0;
        let max_w = 0;
        for (let i = 0; i < row; i++) {
            let max_i_h = 0;
            let one_w = this.getZeroContentSize().width;
            for (let j = 0; j < col; j++) {
                index = i * col + j;
                if (index >= this.itemCount) {
                    break;
                }
                let item = this.getItem(index);
                this.addItem(item);
                // 计算位置区域
                let w = item.getComponent(UITransform).width;
                let h = item.getComponent(UITransform).height;
                max_i_h = h > max_i_h ? h : max_i_h;
                // 设置ContentSize
                one_w = one_w + w + (j == 0 ? 0 : this.spacing.x);
            }
            max_w = one_w > max_w ? one_w : max_w;
            contentW = max_w;
            contentH = contentH + max_i_h + (i == 0 ? 0 : this.spacing.y);
        }
        this.setContentSize(size(contentW, contentH));
        this.cumulativeGridPosition();
    }

    /** 计算位置 */
    private cumulativeGridPosition() {
        let index = 0
        let col = this.grid;
        let row = Math.floor(this.itemCount / this.grid) + 1;
        if (this.itemCount % this.grid == 0) {
            row = Math.floor(this.itemCount / this.grid)
        }
        let preh = 0;
        let start_y = this.getZeroPostion().y;
        for (let i = 0; i < row; i++) {
            let start_x = this.getZeroPostion().x;
            let prew = 0;
            let max_h = 0;
            for (let j = 0; j < col; j++) {
                index = i * col + j;
                if (index >= this.itemCount) {
                    break;
                }
                let item = this.getItem(index);

                let w = item.getComponent(UITransform).width;
                let h = item.getComponent(UITransform).height;
                max_h = h > max_h ? h : max_h;
                // x
                if (this.oderType == ListOderType.Normal) {
                    start_x = start_x + w / 2 + prew / 2 + (j == 0 ? 0 : this.spacing.x);
                } else {
                    start_x = start_x - w / 2 - prew / 2 - (j == 0 ? 0 : this.spacing.x);
                }
                prew = w;

                let start_y_y = start_y
                if (this.oderType == ListOderType.Normal) {
                    start_y_y = start_y - h / 2 - preh / 2 - (i == 0 ? 0 : this.spacing.y);
                } else {
                    start_y_y = start_y + h / 2 + preh / 2 + (i == 0 ? 0 : this.spacing.y);
                }

                // 位置还没设置 先检测是否可见
                item.active = this.checkCollision2(item, start_x, start_y_y, w, h) ? true : false;
                // 增加动画效果
                Tween.stopAllByTarget(item);
                tween(item).to(0.02, { position: new Vec3(start_x, start_y_y, 0) }).start();
                // 
                this.renderItem(index);
            }
            // y
            if (this.oderType == ListOderType.Normal) {
                start_y = start_y - max_h / 2 - preh / 2 - (i == 0 ? 0 : this.spacing.y);
            } else {
                start_y = start_y + max_h / 2 + preh / 2 + (i == 0 ? 0 : this.spacing.y);
            }
            preh = max_h;
        }
    }

    // 网格排列
    private setMyGrid() {
        // 1. 从左往右 从上往下
        // 2. 从左往右 从下往上
        // 3. 从右往左 从上往下
        // 4. 从右往左 从下往上
        const dir = {
            left_to_right: true,
            top_to_bottom: true
        }
    }

    /** 计算位置 */
    private cumulativeMyPosition() {

    }

    /**容器初始最小 */
    private getZeroContentSize(): Size {
        return size(this.horizontal.x + this.horizontal.y, this.vertical.x + this.vertical.y);
    }

    /** 设置容器Size */
    private setContentSize(size: Size) {
        let content = this.getScoll().content;
        content.getComponent(UITransform).contentSize = size;
    }

    private get viewSize(): Size {
        return this.getScoll().view.contentSize;
    }

    // 清理
    public clear() {
        for (let index = 0; index < this.itemArray.length; index++) {
            this.clearItem(index)
            index--;
        }
    }

    /**
     * 清理一个item
     * @param index 
     */
    private clearItem(index) {
        if (this.itemArray[index]) {
            this.itemArray[index].removeFromParent();
        }
        this.itemArray.splice(index, 1);
    }

    /* ***************功能函数*************** */
    /**获取在世界坐标系下的节点包围盒(不包含自身激活的子节点范围) */
    private getBoundingBoxToWorld(node: Node): Rect {
        return node.getComponent(UITransform).getBoundingBoxToWorld();
    }
    /**检测碰撞 */
    private checkCollision(node1: Node): boolean {
        if (!this.isVirtual) {
            return true;
        }
        let rect1 = this.getBoundingBoxToWorld(node1);
        // let rect2 = this.getScoll().view.getBoundingBoxToWorld();
        let view_pos = this.getScoll().view.node.position
        let world_pos = this.getScoll().view.convertToWorldSpaceAR(new Vec3(view_pos.x, view_pos.y, view_pos.z));
        let rect2 = rect(world_pos.x - this.getScoll().view.width / 2, world_pos.y - this.getScoll().view.height / 2, this.getScoll().view.width, this.getScoll().view.height)
        // ------------------保险范围
        return rect1.intersects(rect2);
    }
    private checkCollision2(item: Node, x, y, w, h): boolean {
        if (!this.isVirtual) {
            return true;
        }
        let item_world_pos = item.getComponent(UITransform).convertToWorldSpaceAR(new Vec3(x, y, 0));
        let rect1 = rect(item_world_pos.x - w / 2, item_world_pos.y - h / 2, w, h)

        let view_pos = this.getScoll().view.node.position
        let world_pos = this.getScoll().view.convertToWorldSpaceAR(new Vec3(view_pos.x, view_pos.y, view_pos.z));
        let rect2 = rect(world_pos.x - this.getScoll().view.width / 2, world_pos.y - this.getScoll().view.height / 2, this.getScoll().view.width, this.getScoll().view.height)
        // ------------------保险范围
        return rect1.intersects(rect2);
    }
    /** 刷新显示和隐藏 */
    private updateOpacity(): void {
        if (!this.isVirtual) {
            return;
        }
        let index = 0
        while (index < this.itemCount) {
            let item = this.getItem(index);
            item.active = this.checkCollision(item) ? true : false;
            index++;
        }
    }

    /** 带单选和复选 */
    private isToggleGroup() {
        if (this.getScoll().content.getComponent(ToggleContainer)) {
            return true;
        }
        return false;
    }

    private checkToggle(item: Node, index: number) {
        if (!this.isToggleGroup()) {
            return;
        }
        let toggle = item.getComponent(Toggle) || item.addComponent(Toggle);
        this.getScoll().content.getComponent(ToggleContainer).activeToggles();
        // if (this.onSelectItem) {
        //     // var checkEventHandler = instantiate(this.onSelectItem);
        //     this.onSelectItem.customEventData = index.toString();
        //     this.getComponent(ToggleContainer).checkEvents.push(this.onSelectItem);
        // }
        // if (this.onClickItem) {
        //     var checkEventHandler = instantiate(this.onClickItem);
        //     checkEventHandler.customEventData = index.toString();
        //     toggle.clickEvents.push(checkEventHandler);
        // }
    }

    public isSelected(index): boolean {
        if (!this.isToggleGroup()) {
            return false;
        }
        let item = this.getItem(index);
        let toggle = item.getComponent(Toggle) || item.addComponent(Toggle);
        return toggle.isChecked;
    }

    public scollTo(index: number) {
        if (index < 0 && index >= this.itemCount) {
            return
        }
        let item = this.getItem(index);
        let precent = v2(0, 0);
        if (this.getScoll().horizontal) {
            precent.x = Math.abs(item.position.x / this.getScoll().content.getComponent(UITransform).width);
            if (this.oderType == ListOderType.Normal) {
                this.getScoll().scrollToPercentHorizontal(precent.x, 0.1, true);
            } else {
                this.getScoll().scrollToPercentHorizontal(1 - precent.x, 0.1, true);
            }
        }
        if (this.getScoll().vertical) {
            precent.y = Math.abs(item.position.y / this.getScoll().content.getComponent(UITransform).height);
            if (this.oderType == ListOderType.Normal) {
                this.getScoll().scrollToPercentVertical(1 - precent.y, 0.1, true);
            } else {
                this.getScoll().scrollToPercentVertical(precent.y, 0.1, true);
            }

        }
        // log("scollTo:" + offset.toString())
        // this.getScoll().scrollToOffset(v2(offset.x, offset.y), 0.1, true);

    }

    // private loadItem(){
    //     App.instance.ResManager.loadRes("game/view/CellView", "candy", this, (prefab: Prefab) => {
    //         let node = instantiate(prefab);
    //         this.cells.push(node)
    //     }, Prefab);
    // }

}
