
import { _decorator, Component, Node, EventHandler, ToggleContainer, Toggle, instantiate } from 'cc';
import SuperListView from './SuperListView';
const { ccclass, property, requireComponent } = _decorator;

/**
 * Predefined variables
 * Name = ListToggleGroup
 * DateTime = Mon Jan 24 2022 14:08:15 GMT+0800 (中国标准时间)
 * Author = tombs_tang
 * FileBasename = ListToggleGroup.ts
 * FileBasenameNoExtension = ListToggleGroup
 * URL = db://assets/Script/core/Components/list/ListToggleGroup.ts
 * ManualUrl = https://docs.cocos.com/creator/3.3/manual/zh/
 *
 */

@ccclass('ListToggleGroup')
@requireComponent(SuperListView)
export class ListToggleGroup extends Component {
    @property({ tooltip: "是否单选" })
    private isSingleChoice: boolean = true;

    // !#zh 如果这个设置为 true， 那么 toggle 按钮在被点击的时候可以反复地被选中和未选中。 */		
    @property({ tooltip: "可以反复地被选中和未选中" })
    private allowSwitchOff: boolean = false;

    private toggleContainer: ToggleContainer = undefined;

    start() {
        // [3]
    }

    // update (deltaTime: number) {
    //     // [4]
    // }

    public onLoad() {
        let listview = this.getListView();
        if (this.isSingleChoice) {
            // 自动添加 cc.ToggleContainer
            if (!this.toggleContainer) {
                this.toggleContainer = listview.getScoll().content.addComponent(ToggleContainer);
            }
            this.toggleContainer.allowSwitchOff = this.allowSwitchOff;
        } else {

        }
    }


    private getListView(): SuperListView {
        return this.getComponent(SuperListView);
    }

    /**
    * 如果有cc.Toggle 和 ListToggleGroup 增加对应的选中回调事件
    *  需要满足以下条件 ：
    * 1 .item 根节点上带有 cc.Toggle
    * 2. 列表带有 ListToggleGroup 组件
    */
    private appendToggleEvent(index: number) {
        // let item = this.itemArray[index];
        // if (!item) {
        //     return
        // }
        // let toggle = item.getComponent(Toggle)
        // if (!toggle) {
        //     return;
        // }
        // let listToggleGroup = this.getComponent("ListToggleGroup");
        // if (!listToggleGroup || !listToggleGroup.onSelectHandler) {
        //     return;
        // }
        // var checkEventHandler = instantiate(listToggleGroup.onSelectHandler);
        // checkEventHandler.customEventData = index.toString();
        // toggle.checkEvents.push(checkEventHandler);
    }

}

/**
 * [1] Class member could be defined like this.
 * [2] Use `property` decorator if your want the member to be serializable.
 * [3] Your initialization goes here.
 * [4] Your update function goes here.
 *
 * Learn more about scripting: https://docs.cocos.com/creator/3.3/manual/zh/scripting/
 * Learn more about CCClass: https://docs.cocos.com/creator/3.3/manual/zh/scripting/ccclass.html
 * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.3/manual/zh/scripting/life-cycle-callbacks.html
 */
