
import { _decorator, Component, Node, CCInteger, EventHandler, ScrollView, log } from 'cc';
import SuperListView from './SuperListView';
const { ccclass, property, requireComponent } = _decorator;

/**
 * Predefined variables
 * Name = ListFooter
 * DateTime = Mon Jan 24 2022 14:05:08 GMT+0800 (中国标准时间)
 * Author = tombs_tang
 * FileBasename = ListFooter.ts
 * FileBasenameNoExtension = ListFooter
 * URL = db://assets/Script/core/Components/list/ListFooter.ts
 * ManualUrl = https://docs.cocos.com/creator/3.3/manual/zh/
 *
 */
export enum FooterState {
    Nothing = 0,
    Start,              // 开始拉动
    Refresh             // 触发事件
}


@ccclass('ListFooter')
@requireComponent(SuperListView)
export class ListFooter extends Component {
    // [1]
    // dummy = '';

    // [2]
    // @property
    // serializableDummy = 0;

    @property({ type: Node, tooltip: "头部下拉展示" })
    public headNode: Node = null;

    @property({ type: Node, tooltip: "尾部上拉展示" })
    public footNode: Node = null;

    @property({ type: CCInteger, tooltip: "拉动有效距离" })
    public distance: number = 50;

    /**
   * 触底反弹回调事件
   */
    @property({ type: EventHandler, tooltip: "触底反弹回调事件" })
    public onFooterEvent: EventHandler = null;

    // 状态
    private _state: FooterState = FooterState.Nothing;

    start() {
        // [3]
    }

    // update (deltaTime: number) {
    //     // [4]
    // }

    onEnable() {
        this._registerEvent();
    }
    onDisable() {
        // if (!CC_EDITOR) 
        this._unregisterEvent();
    }

    // ScrollView
    private getScoll(): ScrollView {
        return this.getComponent(ScrollView);
    }

    //注册事件
    private _registerEvent() {
        if (this.getScoll().horizontal) {
            this.node.on("scroll-to-left", this._onScrollToTLeft, this, true);
            this.node.on("scroll-to-right", this._onScrollToRight, this, true);
            // 滚动视图滚动到顶部边界并且开始回弹时发出的事件
            this.node.on("bounce-left", this._onBounceLeft, this, true);
            this.node.on("bounce-right", this._onBounceRight, this, true);
        } else {
            this.node.on("scroll-to-top", this._onScrollToTop, this, true);
            this.node.on("scroll-to-bottom", this._onScrollToBottom, this, true);
            // 滚动视图滚动到顶部边界并且开始回弹时发出的事件
            this.node.on("bounce-top", this._onBounceTop, this, true);
            this.node.on("bounce-bottom", this._onBounceBottom, this, true);
        }
        this.node.on("scroll-ended", this._onScrollEnded, this, true);

    }
    //卸载事件
    private _unregisterEvent() {
        if (this.getScoll().horizontal) {
            this.node.off("scroll-to-left", this._onScrollToTLeft, this, true);
            this.node.off("scroll-to-right", this._onScrollToRight, this, true);
            // 滚动视图滚动到顶部边界并且开始回弹时发出的事件
            this.node.off("bounce-left", this._onBounceLeft, this, true);
            this.node.off("bounce-right", this._onBounceRight, this, true);
        } else {
            this.node.off("scroll-to-top", this._onScrollToTop, this, true);
            this.node.off("scroll-to-bottom", this._onScrollToBottom, this, true);
            // 滚动视图滚动到顶部边界并且开始回弹时发出的事件
            this.node.off("bounce-top", this._onBounceTop, this, true);
            this.node.off("bounce-bottom", this._onBounceBottom, this, true);
        }
        this.node.off("scroll-ended", this._onScrollEnded, this, true);
    }

    // 滚动事件
    private _onScrollEnded(scroll: ScrollView) {
        this._state = FooterState.Nothing;
    }
    private _onScrollToTLeft(scroll: ScrollView) {
        this._state = FooterState.Start;
    }
    private _onScrollToRight(scroll: ScrollView) {
        this._state = FooterState.Start;
    }
    private _onScrollToTop(scroll: ScrollView) {
        this._state = FooterState.Start;
    }
    private _onScrollToBottom(scroll: ScrollView) {
        this._state = FooterState.Start;
    }
    // 滚动视图滚动到顶部边界并且开始回弹时发出的事件
    private _onBounceLeft(scroll: ScrollView) {
        let scrollOffset = scroll.getScrollOffset();
        if (scrollOffset.x > this.distance) {
            this.sendEvent("left");

        }
    }
    private _onBounceRight(scroll: ScrollView) {
        let scrollOffset = scroll.getScrollOffset();
        let maxScrollOffset = scroll.getMaxScrollOffset();
        if (scrollOffset.x < -this.distance - maxScrollOffset.x) {
            this.sendEvent("right");

        }
    }
    private _onBounceTop(scroll: ScrollView) {
        let scrollOffset = scroll.getScrollOffset();
        if (scrollOffset.y < -this.distance) {
            this.sendEvent("top");

        }
    }
    private _onBounceBottom(scroll: ScrollView) {
        let scrollOffset = scroll.getScrollOffset();
        let maxScrollOffset = scroll.getMaxScrollOffset();
        if (scrollOffset.y > this.distance + maxScrollOffset.y) {
            this.sendEvent("bottom");

        }
    }


    private sendEvent(dirc: string) {
        log("列表回弹事件 ： ", dirc);
        this.onFooterEvent.customEventData = dirc;
        EventHandler.emitEvents([this.onFooterEvent]);
    }



}

/**
 * [1] Class member could be defined like this.
 * [2] Use `property` decorator if your want the member to be serializable.
 * [3] Your initialization goes here.
 * [4] Your update function goes here.
 *
 * Learn more about scripting: https://docs.cocos.com/creator/3.3/manual/zh/scripting/
 * Learn more about CCClass: https://docs.cocos.com/creator/3.3/manual/zh/scripting/ccclass.html
 * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.3/manual/zh/scripting/life-cycle-callbacks.html
 */
